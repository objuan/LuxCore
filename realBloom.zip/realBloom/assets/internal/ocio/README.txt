This directory contains a copy of grace, the default internal OpenColorIO config for RealBloom. Please do not modify the contents unless you know what you're doing.  

Links:
  RealBloom - https://github.com/bean-mhm/realbloom
  grace - https://github.com/bean-mhm/grace

Last Updated: 2023-08-11
