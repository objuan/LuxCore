This directory contains a copy of grace, the default OpenColorIO config for RealBloom.
You are free to swap the contents of this directory with your own custom OCIO config.

Links:
  RealBloom - https://github.com/bean-mhm/realbloom
  grace - https://github.com/bean-mhm/grace

Last Updated: 2023-08-11
